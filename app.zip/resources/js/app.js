import './bootstrap';

import('./carousel');

import('./togglenav');

import('./toggleshopmenu')

import('./similar-slider')

import('./logo-name-setter')

import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();



